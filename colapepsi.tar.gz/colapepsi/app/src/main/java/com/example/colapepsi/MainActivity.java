package com.example.colapepsi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageButton incrementButtonp;
    TextView counterp;
    ImageButton incrementButtonc;
    TextView counterc;
    int p;
    int c;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        incrementButtonp = findViewById(R.id.pepsibutton);
        counterp = findViewById(R.id.pepsicount);
        p = 0;
        incrementButtonc = findViewById(R.id.colabutton);
        counterc = findViewById(R.id.colacount);
        c = 0;


        incrementButtonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ++c;
                counterc.setText(""+c);
            }
        });
        incrementButtonp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ++p;
                counterp.setText(""+p);
            }
        });

    }
}